package com.shaoxi.scanorder.service;

import com.github.pagehelper.PageInfo;
import com.shaoxi.scanorder.entity.ScanErrInfoEntity;
import java.util.Map;

public interface ScanErrInfoMapper{
	public List<ScanErrInfoEntity> query(ScanErrInfoEntity scanErrInfo);
	
	public Long save(ScanErrInfoEntity scanErrInfo);
	
}
