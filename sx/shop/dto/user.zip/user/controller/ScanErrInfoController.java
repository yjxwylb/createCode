package com.jiuyescm.erp.example.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.shaoxi.scanorder.exception.BizException;
import com.shaoxi.scanorder.rest.Response;
import com.github.pagehelper.PageInfo;




@RestController
@RequestMapping("/api")
public class ScanErrInfoController {

    private static final Logger logger = LoggerFactory.getLogger(ScanErrInfoController.class.getName());

    @Resource
    private IScanErrInfoService scanErrInfoService;

    @RequestMapping(value = "/scanErrInfo", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public Response<ScanErrInfoVO> save(@RequestBody ScanErrInfoVO vo) {
        logger.info(vo.toString());
       
        Response<ScanErrInfoVO> res = new Response<ScanErrInfoVO>();
        try {
            Long id = scanErrInfoService.save(vo);
            vo.setId(id);
        } catch (BizException e) {
            throw e;
        }
        res.setItems(vo);
        return res;
    }

    @RequestMapping(value = "/scanErrInfo", method = RequestMethod.GET)
    public Response<PageInfo<ScanErrInfoVO>> getList(@RequestParam(required = false) String name,
            @RequestParam(value = "page", defaultValue = "1") Integer page,
            @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize) {
        Response<PageInfo<ScanErrInfoVO>> res = new Response<PageInfo<ScanErrInfoVO>>();
        ScanErrInfoVO vo = new ScanErrInfoVO();
        res.setItems(scanErrInfoService.query(vo, page, pageSize));
        return res;
    }

}
