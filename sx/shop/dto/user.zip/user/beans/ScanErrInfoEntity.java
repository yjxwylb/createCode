package com.shaoxi.scanorder.entity;

import lombok.Data;

@Data
public class ScanErrInfoEntity{
	/** 主键自增id */
	private Long id;
	/** 扫码无法判断按摩椅的qrcode_address值 , 对应Oracle数据库中的 T_CHAIRS_INFO.qrcode_address */
	private String qrcodeAddress;



	@Override
	public String toString() {
	  return "ScanErrInfoEntity{" + 
	  			"id:" + getId() +","+
	  			"qrcodeAddress:" + getQrcodeAddress() +
	      '}';
	}

}

