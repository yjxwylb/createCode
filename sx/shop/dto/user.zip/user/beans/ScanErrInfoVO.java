package com.shaoxi.scanorder.VO;

import lombok.Data;

@Data
public class ScanErrInfoVO implements Serializable{
	/** 主键自增id */
	private Long id;
	/** 扫码无法判断按摩椅的qrcode_address值 , 对应Oracle数据库中的 T_CHAIRS_INFO.qrcode_address */
	private String qrcodeAddress;



	@Override
	public String toString() {
	  return "ScanErrInfoVO{" + 
	  			"id:" + getId() +","+
	  			"qrcodeAddress:" + getQrcodeAddress() +
	      '}';
	}

}

