package com.shaoxi.scanorder.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.shaoxi.scanorder.entity.ScanErrInfoEntity;
import com.shaoxi.scanorder.repository.IScanErrInfoRepository;
import com.shaoxi.scanorder.service.IScanErrInfoService;

 

@Service
public class ScanErrInfoServiceImpl implements IScanErrInfoService {
	private static final Logger logger = LoggerFactory.getLogger(ScanErrInfoServiceImpl.class);
	@Autowired
	private ScanErrInfoMapper scanErrInfoMapper;

	@Override
	public Long save(ScanErrInfoVO scanErrInfoVO){
		ScanErrInfoEntity entity = new ScanErrInfoEntity();
        BeanUtils.copyProperties(scanErrInfoVO, entity);
		scanErrInfoMapper.save(entity);
		return entity.getId();
	}

	@Override
	public PageInfo<ScanErrInfoVO> query(ScanErrInfoVO scanErrInfoVO, int pageNo, int pageSize) {
		ScanErrInfoEntity entity = new ScanErrInfoEntity();
		BeanUtils.copyProperties(scanErrInfoVO, entity);
        PageHelper.startPage(pageNo, pageSize);
        List<ScanErrInfoEntity> list = scanErrInfoMapper.query(entity);
        PageInfo<ScanErrInfoEntity> page = new PageInfo<ScanErrInfoEntity>(list);
        PageInfo<ScanErrInfoVO> result=null;
        try {
        	result=PageCopyUtil.copyTo(page, ScanErrInfoVO.class);
        } catch (Exception e) {
            logger.error("error entity to vo runtimeException", e);
        }
        return result;
	}
    
}