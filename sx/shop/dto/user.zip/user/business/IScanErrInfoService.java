package com.shaoxi.scanorder.service;

import com.github.pagehelper.PageInfo;

import com.shaoxi.scanorder.entity.ScanErrInfoEntity;
import java.util.Map;

public interface IScanErrInfoService{
	public PageInfo<ScanErrInfoVO> query(ScanErrInfoVO scanErrInfoVO, int pageNo, int pageSize) throws BizException;
	
	public Long save(ScanErrInfoVO scanErrInfo) throws BizException;
	
}
